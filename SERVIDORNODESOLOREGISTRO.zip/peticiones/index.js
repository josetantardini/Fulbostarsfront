const express = require('express')
const app = express()
const bodyparser = require('body-parser')
const http = require('http');
const fetch = require('cross-fetch')
const mysql = require('mysql');
const crypto = require('crypto');

var conexion = mysql.createConnection({
    host: 'localhost',
    database: 'fulbostars',
    user: 'root',
    password: 'root'
})

conexion.connect(function(error) {
    if (error) {
        throw error;
    } else {
        console.log('Conexion exitosa a la base de datos')
    }
})


app.use(express.json());
app.use(express.urlencoded())


app.use((req, res, next) => {

    // Dominio que tengan acceso (ej. 'http://example.com')
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Metodos de solicitud que deseas permitir
    res.setHeader('Access-Control-Allow-Methods', 'POST');

    // Encabecedados que permites (ej. 'X-Requested-With,content-type')
    res.setHeader('Access-Control-Allow-Headers', '*');

    next();
})

app.post("/", function(req, res) {




    if (req.body.user) {


        const email = req.body.user.email;
        let mobile = req.body.user.mobile;
        const city = req.body.user.city;
        const country = req.body.user.country;
        const name = req.body.user.name;
        const lastname = req.body.user.lastname;
        const subscribe = req.body.user.subscribe;
        const password = req.body.user.password;
        const terms = req.body.user.terms;
        const billetera = req.body.user.billetera;
        const camiseta = req.body.user.camiseta;
        const escudo = req.body.user.escudo;
        const avatar = req.body.user.avatar;
        let bandera = 0;
        conexion.query(`SELECT * FROM users WHERE email = '${email}' OR mobile= '${mobile}'`, function(error, results, fields) {
            if (error)
                throw error;


            if (results.length === 0) {

                if (mobile === null) {
                    mobile = email;
                    bandera = 1;
                }



                conexion.query(`INSERT INTO users (escudo,camiseta,billetera,name, lastname, mobile,country,city,email,subscribe,avatar,pass,terms,usertype,activo)
                VALUES ( '${escudo}','${camiseta}','${billetera}','${name}',  '${lastname}',  '${mobile}', '${country}', '${city}', '${email}', '${subscribe}','${avatar}', '${password}', '${terms}','0','0'   );`, function(error, results, fields) {
                    if (error)
                        throw error;


                })

                // estos codigos deverian de enviarse al email y al mobile, antes de enviar json validar si se envio el email
                //EN ESTE PUNTO DEL CODIGO DEVERIAN DE ENVIARSE LOS CIDOGOS GENERADOS UNO PARA EMAIL Y OTRO PARA SMS segun corresponda
                const codigoemail = crypto.randomBytes(3).toString('hex');
                console.log(bandera);
                // SI EL USUARIO UNICAMENTE INGRESO EMAIL SE ENVIA CORREO UNICAMENTE, ESTO ES LO QUE HACE LA VALIDACION
                if (bandera === 1) {
                    res.json({ "codigoemail": codigoemail });
                    console.log(codigoemail);
                } else {

                    //SI EL USUARIO INGRESO MOBILE Y EMAIL SE ENVIA SMS Y CORREO
                    const codigomobile = crypto.randomBytes(3).toString('hex');
                    res.json({
                        "codigomobile": codigomobile,
                        "codigoemail": codigoemail
                    });
                    console.log(codigomobile);
                    console.log(codigoemail);

                }


            } else {
                res.json({ "error": "Email o Numero ya registrado" });
            }




        })





    }

    //SI EL USUARIO VALIDO LA CUENTA, OSEA SI INGRESO LOS CODIGOS CORRECTAMENTE EL SERVIDOR ACTUALIZA EL ESTADO DE SU CUENTA A ACTIVO = 1

    if (req.body.successcod) {

        const user = req.body.successcod.usuario;

        conexion.query(`UPDATE users SET activo='1' WHERE email= '${user}';`, function(error, results, fields) {
            if (error) {
                throw error;
            }
            res.json({ "bien": "Felicidades se a registrado correctamente" });

        })


    }
    // SI EXPIRO EL TIEMPO DE VALIDAR LA CUENTA O REALIZO MAS DE 3 INTENTOS COLOCANDO EL CODIGO ERRONEO BORRA SUS DATOS DE LA BASE DE DATOS
    if (req.body.destruir) {
        const userdes = req.body.destruir.usuario;
        //ACA DEBERIA DE EXISTIR ALGUN TEMPORIZADOR PARA QUE SI NO INGRESAN LOS CODIGOS DURANTE UN TIEMPO AUTOMATICAMENTE SE BORRE EL USUARIO INGRESADO EN LA BASE DE DATOS
        conexion.query(`DELETE FROM users WHERE email='${userdes}'`, function(error, results, fields) {
            if (error) {
                throw error;
            }
            res.json({ "MAL": "ERROR" });

        })
    }









});

app.listen(4000);